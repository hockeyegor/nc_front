import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-google-service',
  templateUrl: './google-service.component.html',
  styleUrls: ['./google-service.component.css']
})
export class GoogleServiceComponent implements OnInit {
  ngOnInit(): void {
  }
}